<?php
function add_registration($customerId, $productCode) {
    // ???
}
?>