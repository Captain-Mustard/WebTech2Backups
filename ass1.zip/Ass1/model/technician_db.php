<?php
function getTechnicians() {
    // ???
}

function deleteTechnician($technician_id) {
    // ???
}

function addTechnician($firstName, $lastName, $email, $phone, $password) {
    // ???
}

function updateTechnician($technician_id, $firstName, $lastName, $email, $phone, $password) {
    // ???
}

?>