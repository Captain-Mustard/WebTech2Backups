<?php
function getCustomers() {
    // ???
}

function getCustomer_lastName($lastName) {
    // ???
}

function getCustomer($customerId) {
    // ???
}

function get_customer_by_email($email) {
    // ???
}

function deleteCustomer($customerId) {
    // ???
}

function addCustomer($firstName, $lastName, 
        $address, $city, $state, $postal_code, $country_code,
        $phone, $email, $password) {
    // ???
}

function updateCustomer($customerId, $firstName, $lastName,
        $address, $city, $state, $postal_code, $country_code,
        $phone, $email, $password) {
   // ???
}
?>