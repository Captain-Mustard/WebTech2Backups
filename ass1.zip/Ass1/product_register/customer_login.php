<?php include '../view/header.php'; ?>
<main>

    <h2>Customer Login</h2>
    <p>You must login before you can register a product.</p>
    <!-- display a search form -->
    <form action="." method="post">
        <!--  ??? -->
    </form>

</main>
<?php include '../view/footer.php'; ?>