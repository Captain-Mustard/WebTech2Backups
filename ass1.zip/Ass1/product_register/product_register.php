<?php include '../view/header.php'; ?>
<main>

    <h2>Register Product</h2>
    <?php if (isset($message)) : ?>
        <!--  ??? -->
    <?php else: ?>
        <form action="." method="post" id="aligned">
           <!--  ??? -->
        </form>
    <?php endif; ?>
</main>
<?php include '../view/footer.php'; ?>