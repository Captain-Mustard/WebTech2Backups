<?php include '../view/header.php'; ?>
<main>
    <h1>Add Technician</h1>
    <form action="." method="post" id="aligned">
        <!--  ??? -->
    </form>
    <p><a href="?action=listTechnicians">View Technician List</a></p>
</main>
<?php include '../view/footer.php'; ?>